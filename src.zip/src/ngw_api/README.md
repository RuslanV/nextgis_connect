# ngw_external_api_python
NextGIS Web External Python API

License
-------------
This program is licensed under GNU GPL v2 or any later version

Commercial support
----------
Need to fix a bug or add a feature to NextGIS Web External Python API? We provide custom development and support for this software. [Contact us](https://nextgis.com/contact/) to discuss options!

[![https://nextgis.com](https://nextgis.ru/img/nextgis.png)](https://nextgis.com)
